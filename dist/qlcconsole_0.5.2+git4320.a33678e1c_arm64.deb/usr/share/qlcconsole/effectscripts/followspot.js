/*
  QLC+ Effect Script: Followspot
  Move a set of fixtures using two joystick axes (pan/tilt).
  Compatible with any gamepad or MIDI controller mapped to the x/y inputs.

  Velocity-based: the stick deflects a setpoint at a rate proportional to
  deflection.  Releasing the stick holds the current position, so the beam
  stays put without continuous pressure.  Setpoint is initialized from the
  Aim target when one is bound (followTarget slot), allowing smooth handoff
  from a pre-set scene Aim palette position.
*/
(function() {
    var effect = new Object;
    effect.apiVersion  = 1;
    effect.name        = "Followspot";
    effect.description = "Pan/tilt fixtures with joystick X/Y axes";
    effect.author      = "QLC+";
    effect.fixtureTypes = ["moving"];
    effect.notes = "Maps joystick X/Y axes to pan and tilt so you can fly moving heads live. This effect controls POSITION — it never touches colour, and it touches the dimmer only when Fade Near Limit or Fade When Blocked is set, so the scene's own Color/Dimmer palettes otherwise retain control. Fade Near Limit dims a head as the target nears the edge of what it can point at, reaching dark where it cannot follow, so it goes out rather than sticking lit at its limit. Fade When Blocked takes a head out, over that many milliseconds, while something solid on stage -- a closed drape, a wall, a riser, a tower -- stands between it and the subject, and brings it back once the way is clear. Framing sizes the beam from the followed Person's Height -- Head & Shoulders, Waist Up or Full Body -- and keeps the top of the beam just over their head; Framing Size makes it looser or tighter; Custom uses the Width On Subject, which zooms each head that has a zoom so its beam is that wide where it lands on the subject, whatever the throw -- a near head zooms out, a far one in -- within the lens's range. D-pad Left and Right close and open the beam while it plays (the Framing Size, the Width on Subject, or the beam angle when no size is set); Save Positions keeps it. Top Speed is how fast the subject moves on the stage with the left stick at full throw (a brisk walk by default); the right stick moves it finer (Fine Stick, a share of Top Speed) and the two add; Response Curve makes the stick fine near the centre; D-pad Up and Down step the speed (x0.25 to x2) while it plays. Deadzone is the controller's (HID device profile). Person Height biases the tilt centre so the beam lands at the subject's head. Bind the followTarget slot to a stage target to seed the initial position from a pre-set Aim palette.";

    // The host injects joystick data automatically when a HID profile is active.
    // Manual input bindings (x / y) are kept as a fallback for non-HID controllers.
    effect.dataChannels = ["joystick"];

    effect.inputs = [
        { name: "x", description: "Pan axis fallback (0=left, 0.5=center, 1=right)", defaultValue: 0.5 },
        { name: "y", description: "Tilt axis fallback (0=up, 0.5=center, 1=down)",   defaultValue: 0.5 }
    ];

    // Position-only effect: no colour or dimmer palettes. The scene's own
    // Color/Dimmer palettes are left untouched so movement composes on top of
    // whatever look is active.
    effect.palettes = [];

    // No target binding: the followspot reads its target IMPLICITLY from the
    // scene's own Aim look.  The host injects that as fixture.sceneTarget and,
    // when present, moves the shared aim point so the heads converge — this
    // effect then defers (emits no pan/tilt).  Free-fly (no Aim look) is the
    // only case this script flies angles itself.

    // Sensitivity and deadzone are deliberately NOT effect parameters — they are
    // global joystick settings (HID device profile / I/O Manager) and arrive via
    // the joystick data channel. Only the followspot-specific person-height bias
    // and the scene-transition seeding mode are configured here.
    //
    // followMode controls where the beam starts when this effect takes over from
    // a previous scene:
    //   "lastPosition" (default) — resume from the last spot position the beam
    //       was left at, so the heads DON'T move on transitions between scenes.
    //       Falls back to the bound followTarget (then physical centre) the very
    //       first time, when no last position has been recorded yet.
    //   "snapToTarget" — snap to the bound followTarget's pre-aimed position on
    //       every transition (ignores the last spot position).
    effect.parameters = [
        { name: "followMode",   label: "Follow Mode", description: "On scene change: hold the last beam position, or snap to the bound followTarget", values: ["lastPosition", "snapToTarget"], valueLabels: ["Hold Last Position", "Snap to Target"], defaultValue: 0 },
        { name: "personHeight", label: "Person Height", description: "Height of the person being followed (free-fly only) -- adjusts the tilt centre", unit: "cm", min: 50, max: 250, defaultValue: 170 },
        { name: "fadeNearLimit", label: "Fade Near Limit", description: "Fade a head out over this many degrees before its pan/tilt limit, dark where it cannot reach the target (0 = off)", min: 0, max: 45, defaultValue: 0 },
        { name: "fadeWhenBlocked", label: "Fade When Blocked", description: "Fade a head out over this many milliseconds while a drape, wall, riser or tower stands between it and the subject, back when clear (0 = off)", min: 0, max: 5000, defaultValue: 0 },
        // Framing: how much of the person the beam takes, sized from the
        // followed Person's Height, each head from its own throw and lens
        // (the host's FollowSpotFraming). Custom is the Width on Subject.
        { name: "framing", label: "Framing", description: "How much of the followed person the beam takes, from their Height: head and shoulders, waist up, the full body, or Custom (the Width on Subject)", values: ["custom", "headShoulders", "waistUp", "fullBody"], valueLabels: ["Custom", "Head & Shoulders", "Waist Up", "Full Body"], defaultValue: 0 },
        { name: "framingSize", label: "Framing Size", description: "The Framing a little looser or tighter: 100% as it is, 110% a tenth wider. D-pad Left and Right step it while the follow spot plays; Save Positions keeps it", unit: "%", min: 25, max: 300, defaultValue: 100, activeWhen: [{ param: "framing", not: [0] }] },
        { name: "sizeOnSubject", label: "Width on Subject", description: "Custom: zoom each head so its beam is this wide on the subject, whatever its distance (0 = off). D-pad Left and Right step it while the follow spot plays", unit: "cm", min: 0, max: 800, defaultValue: 0, activeWhen: [{ param: "framing", is: [0] }] },
        { name: "beamAngle", label: "Beam Angle", description: "With no size on the subject: the beam angle every head zooms to, in degrees (0 = the scene's own zoom). D-pad Left and Right step it while the follow spot plays", unit: "°", min: 0, max: 90, defaultValue: 0, activeWhen: [{ param: "framing", is: [0] }, { param: "sizeOnSubject", is: [0] }] },
        // The feel (the host moves the subject with these; free-fly below too).
        // A speed is kept in cm a second and shown in Settings > Units.
        { name: "topSpeed", description: "Top Speed (how fast the subject moves on the stage with the left stick at full throw: a brisk walk is the default)", unit: "cm/s", min: 15, max: 600, defaultValue: 182.88 },
        { name: "fineStick", description: "Fine Stick (the right stick's full throw, as a percentage of Top Speed: for small corrections)", unit: "%", min: 5, max: 100, defaultValue: 20 },
        { name: "responseCurve", description: "Response Curve (0 = speed follows the stick evenly; higher = fine near the centre, Top Speed only at full throw)", unit: "%", min: 0, max: 100, defaultValue: 40 }
    ];

    effect.tick = function(fixtures, inputs, palettes, params, state, data) {
        // Prefer automatic joystick data channel (HID profile active) over
        // manual input bindings — fall back to inputs.x/y for other controllers.
        var joystick = data && data.joystick;
        var rawX  = joystick ? joystick.pan  : (inputs.x !== undefined ? inputs.x  : 0.5);
        var rawY  = joystick ? joystick.tilt : (inputs.y !== undefined ? inputs.y  : 0.5);

        // sensitivity / deadzone are GLOBAL joystick settings, supplied by the
        // host through the joystick data channel (HID profile / I/O Manager).
        // Fall back to conservative defaults when no joystick channel is active.
        var dz  = (joystick && joystick.deadzone    !== undefined) ? joystick.deadzone    : 0.05;
        var sen = (joystick && joystick.sensitivity !== undefined) ? joystick.sensitivity : 1.0;
        var pH  = params.personHeight !== undefined ? params.personHeight : 170;

        // Tilt bias: 170 cm is neutral; person height shifts the setpoint at init.
        // Applied once at initialization rather than every tick.
        var tiltBias = (170 - pH) / 300 * 0.12;  // fraction of tilt range

        // Velocity from stick position: 0 at centre/deadzone, ±1 at extremes
        // (the fallback, for a controller the host does not drive).
        function axisVelocity(v) {
            var delta = v - 0.5;
            if (Math.abs(delta) < dz) return 0.0;
            var sign  = delta > 0 ? 1 : -1;
            var scale = (Math.abs(delta) - dz) / (0.5 - dz);
            return sign * scale;
        }

        var xVel = axisVelocity(rawX);
        var yVel = axisVelocity(rawY);

        // The time this tick really took (seconds), not an assumed 20 ms: a
        // late tick moves as far as the stick was held for. Capped, so a
        // stall is not one big jump.
        var now = inputs._time;
        var dt = 0.02;
        if (now !== undefined && state.lastTime !== undefined)
            dt = Math.max(0, Math.min(0.1, now - state.lastTime));
        if (now !== undefined)
            state.lastTime = now;

        // The host's follow spot motion: how fast to go on the stage, in
        // metres a second (Top Speed, the speed step, the response curve and
        // the fine stick in it, eased in and out). Free-fly turns it into
        // pan and tilt below.
        var hostVel = joystick && joystick.vx !== undefined;
        var vx = hostVel ? joystick.vx : 0;
        var vy = hostVel ? joystick.vy : 0;
        var centre = hostVel && joystick.cx !== undefined
                     ? { x: joystick.cx, y: joystick.cy, z: joystick.cz } : { x: 0, y: 0, z: 0 };

        // With no size on the subject: the beam angle (the look's, or the
        // pad's for this run -- the host hands it over as beamAngle).
        var angle = params.beamAngle !== undefined ? params.beamAngle : 0;

        // A beam angle on this head's lens, 0..1 of its zoom.
        function zoomFor(f, deg) {
            var span = f.lensMax - f.lensMin;
            return Math.min(1, Math.max(0, (deg - f.lensMin) / span));
        }

        // Shortest-path / no-wipe between scenes is handled host-side in the
        // target case (the aim point moves in floor space, a straight line);
        // free-fly below simply integrates the stick from centre.

        return fixtures.map(function(f) {
            var intent = {};

            if (f.hasPanTilt) {
                // TARGET MODE: when the scene has an aim target, the host moves the
                // shared aim point with the joystick and the scene's Aim look
                // re-aims EVERY head at it, so multiple heads stay converged on the
                // spot (per-fixture angle flying can't do that — equal angle steps
                // from different geometries diverge).  Emit no pan/tilt here so this
                // effect doesn't fight the Aim look; it just declares the scene a
                // followspot and carries followMode / personHeight.
                var hasTarget = f.sceneTarget && f.sceneTarget.pan !== undefined;
                if (hasTarget) {
                    // Fade near the limit: the head is about to stick where it
                    // can go no further, so take its light down with the
                    // margin it has left, dark once it cannot reach. Only the
                    // dimmer, and only while fading -- a tick that writes no
                    // dimmer hands the channel straight back to the scene.
                    var fade = params.fadeNearLimit !== undefined ? params.fadeNearLimit : 0;
                    var margin = f.sceneTarget.reachMargin;
                    var level = 1;
                    if (fade > 0 && margin !== undefined && margin < fade)
                        level = Math.max(0, margin / fade);

                    // Fade when blocked: something solid on stage between
                    // the head and the subject (the host's line of sight,
                    // f.sceneTarget.blocked). Ramp out over the set time
                    // while blocked and back up once clear; same hand-back
                    // as above -- no dimmer once it is all the way up.
                    var blockFade = params.fadeWhenBlocked !== undefined ? params.fadeWhenBlocked : 0;
                    var seenKey = "seen_" + f.id;
                    if (blockFade > 0 && f.sceneTarget.blocked !== undefined) {
                        var seen = state[seenKey] !== undefined ? state[seenKey] : 1;
                        // A tick's worth of the fade (a 50 Hz tick, as it always was).
                        var step = 20 / blockFade;
                        seen = f.sceneTarget.blocked ? Math.max(0, seen - step)
                                                     : Math.min(1, seen + step);
                        state[seenKey] = seen;
                        level = Math.min(level, seen);
                    } else if (state[seenKey] !== undefined) {
                        delete state[seenKey];
                    }
                    if (level < 1)
                        intent.dimmer = level;

                    // Width on subject: the angle that makes the beam this wide
                    // at this distance, placed within what the lens can do. A
                    // subject closer than the lens's narrowest can make small
                    // gets the narrowest; one further than its widest can make
                    // big gets the widest.
                    // The width wanted on the subject from this head
                    // (metres): the host works it out (FollowSpotFraming --
                    // the Framing from the person's height and this head's
                    // throw, or the Width on Subject; the pad's change in
                    // it). None: the beam angle, if one is set.
                    var width = f.sceneTarget.beamWidth !== undefined ? f.sceneTarget.beamWidth : 0;
                    var dist = f.sceneTarget.distance;
                    if (width > 0 && f.hasZoom && dist !== undefined && dist > 0.05) {
                        var want = 2 * Math.atan(width / 2 / dist) * 180 / Math.PI;
                        intent.zoom = zoomFor(f, want);
                    } else if (width <= 0 && f.hasZoom && angle > 0) {
                        intent.zoom = zoomFor(f, angle);
                    }
                    return intent;
                }

                // FREE-FLY (no target): the operator flies this head's angle from
                // centre with the stick.  Coherent for a single head; with no shared
                // point there is nothing to converge on.
                var panKey  = "pan_"  + f.id;
                var tiltKey = "tilt_" + f.id;

                // Sentinel until the first stick move leaves the deadzone, so the
                // scene retains DMX control until the operator actually flies it.
                if (state[panKey] === undefined) {
                    state[panKey]  = null;
                    state[tiltKey] = null;
                }

                // Degrees a second for each axis: the host's stage speed
                // over the head's throw to the middle of the stage (a speed
                // on the stage, the same both ways), else the old fallback
                // (a whole range a second at full throw).
                var panRate, tiltRate;
                if (hostVel) {
                    var p = f.pos || { x: 0, y: 0, z: 0 };
                    var dx = p.x - centre.x, dy = p.y - centre.y, dzz = p.z - centre.z;
                    var throwM = Math.max(1, Math.min(50, Math.sqrt(dx * dx + dy * dy + dzz * dzz)));
                    var degPerM = 180 / Math.PI / throwM;
                    panRate  =  vx * degPerM;
                    tiltRate = -vy * degPerM;     // up the stage: tilt as the stick pushed up did
                } else {
                    panRate  = xVel * f.panRange  * sen;
                    tiltRate = yVel * f.tiltRange * sen;
                }

                if (panRate !== 0.0 || tiltRate !== 0.0) {
                    if (state[panKey] === null) {
                        state[panKey]  = 0.5 * f.panRange;
                        state[tiltKey] = (0.5 + tiltBias) * f.tiltRange;
                    }
                    state[panKey]  = Math.min(f.panRange,  Math.max(0, state[panKey]  + panRate  * dt));
                    state[tiltKey] = Math.min(f.tiltRange, Math.max(0, state[tiltKey] + tiltRate * dt));
                }

                if (state[panKey] !== null) {
                    intent.pan  = state[panKey];
                    intent.tilt = state[tiltKey];
                }
                // No subject to size on: the beam angle alone, if set.
                if (f.hasZoom && angle > 0)
                    intent.zoom = zoomFor(f, angle);
            }

            // Position only here: no colour or dimmer in the intent, so the
            // scene's own Color/Dimmer palettes retain control (the exceptions
            // are the reach fade and the zoom for size above).
            return intent;
        });
    };

    return effect;
})()
