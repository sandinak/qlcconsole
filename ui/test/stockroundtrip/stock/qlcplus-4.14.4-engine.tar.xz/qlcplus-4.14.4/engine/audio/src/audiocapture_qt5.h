/*
  Q Light Controller Plus
  audiocapture_qt5.h

  Copyright (c) Massimo Callegari

  Licensed under the Apache License, Version 2.0 (the "License");
  you may not use this file except in compliance with the License.
  You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0.txt

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
*/

#ifndef AUDIOCAPTURE_QT5_H
#define AUDIOCAPTURE_QT5_H

#include "audiocapture.h"

#include <QAudioInput>

/** @addtogroup engine_audio Audio
 * @{
 */

class AudioCaptureQt5 final : public AudioCapture
{
    Q_OBJECT
public:
    AudioCaptureQt5(QObject * parent = 0);
    ~AudioCaptureQt5();

    /** @reimpl */
    qint64 latency() const override;

    /** @reimpl */
    void setVolume(qreal volume) override;

protected:
    /** @reimpl */
    bool initialize() override;

    /** @reimpl */
    virtual void uninitialize() override;

    /** @reimpl */
    void suspend() override;

    /** @reimpl */
    void resume() override;

    /** @reimpl */
    bool readAudio(int maxSize) override;

private:
    QAudioInput *m_audioInput;
    QIODevice *m_input;
    QAudioFormat m_format;
    qreal m_volume;
    QByteArray m_currentReadBuffer;
};

/** @} */

#endif // AUDIOCAPTURE_QT5_H
